package polidorifilippoeserciziocontocorrente;

/**
 *
 * @author polidori.filippo
 */
public class ContoCorrente {
    
    private String nome;
    private String cognome;
    private double contoCorrente;
    private double cifraPrelievoVersamento;
    private int scelta;
    
    public ContoCorrente(String nome, String cognome, double contoCorrente, double cifraPrelievoVersamento, int scelta){
        
        this.nome=nome;
        this.cognome=cognome;
        this.contoCorrente=contoCorrente;
        this.cifraPrelievoVersamento=cifraPrelievoVersamento;
        this.scelta=scelta;
        
    }
     
    public String getNome(){
        
        return nome;
        
    }
    
    public String getCognome(){
        
        return cognome;
        
    }
    
    public double getContoCorrente(){
        
        return contoCorrente;
        
    }
    
    public int getScelta(){
        
        return scelta;
        
    }
    public double getCifra(){
        
        return cifraPrelievoVersamento;
   }
    
    
    public String controlloScelta(){
        
        if(scelta == 1){
            
            if(contoCorrente>cifraPrelievoVersamento || contoCorrente==cifraPrelievoVersamento){
                
                contoCorrente=contoCorrente-cifraPrelievoVersamento;
                return "Nel conto corrente ora hai: " + contoCorrente + "€";
            }
            else if (contoCorrente<cifraPrelievoVersamento){
                
                return "Impossibile prelevare, saldo insufficiente";
            }
        }
        else if(scelta == 2){
            
            contoCorrente=contoCorrente+cifraPrelievoVersamento;
            return "Nel conto corrente ora hai: " + contoCorrente;
        }
        else if(scelta == 0 || scelta > 2){
            
            return "Nessuna operazione richiesta";
        }
        return null;
    }
    
    public String toString(){
        
        return "nome: " + nome + " - cognome: " + cognome + " - conto corrente: " + contoCorrente + " - cifra da prelevare o da versare: " + cifraPrelievoVersamento + " - numero scelto: " + scelta;
    }
}

