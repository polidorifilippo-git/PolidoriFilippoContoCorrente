/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package polidorifilippoeserciziocontocorrente;

/**
 *
 * @author polidori.filippo
 */
public class PolidoriFilippoEsercizioContoCorrente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
      
        
       ContoCorrente cc1 = new ContoCorrente("Francesco","Beacci", 204, 124, 2); //inserire nell'ultima cifa il numero 1 per prelevare e il numero 2 per versare
       
       System.out.println(cc1);
    }
    
}
